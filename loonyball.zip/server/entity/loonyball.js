var entityModel = require('../entity.js');

var Loonyball = function (broadcast) {
    var loonyball = {};
    loonyball = new entityModel(broadcast);
    /**
     * Create entity
     * here fill new entity with initial data
     *
     * @important interface method
     * @param socket object connexion
     */
    loonyball.create = function create (connexion) {
        this.id = connexion.id;
        var data = {
            id:this.index,
            position : {
                x: -0.5 ,
                y: 0.5 ,
                z: 2
            }
        };

        this.add = function() {
            this.client_entities[this.index] = new this.entity(connexion.id);
            this.client_entities[this.index].remoteOpts = data;
            return this.client_entities[this.index];
        };

        var client_entities_created = this.add();

        this.customUpdate(this.id, this.client_entities);
        return client_entities_created;
    };

    /**
    * Action dealer
    *
    * @important interface method
    */
    loonyball.action = function (connexionId, action, data) {
        this.shoot = function(connexionId, data) {
            console.log('Requested action => SHOOT');
        },
        this.target = function(connexionId, data) {
            console.log('Requested action => TARGET');
        },
        this.update = function (data) {
            this.setRemoteOpts(data);
            this.broadcast.update({f:'entity.update', d:this.getRemoteOpts()});
        };

        switch (action) {
            case 'target' : this.target(connexionId, data);break;
            case 'shoot' : this.shoot(connexionId, data);break;
            case 'move' : this.move(connexionId, data);break;
            case 'entity.update' : this.update(data);break;
            default : console.log('-- ' + action + ' -- Requested action do not exists');break;
        }
    };

    return loonyball;
};
module.exports = Loonyball;
