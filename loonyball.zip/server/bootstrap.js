/**
 * App bootstrap
 */
var config = require('./config').config;
var app = require('./app');
app.init(config);
