var sockjs = require('./lib/sockjs');
var broadcast = require('./broadcast.js');
var http = require('http');
var client_ids = [];
var client_id = 1;

/**
 * Initialize Application
 *
 * @param config
 */
exports.init = function(config) {
    var config = config;
    try {

        /**
         * Setupd broadcast
         */
        broadcast = new broadcast();

        /**
         * Setup game entity
         */
        var entity = require('./entity/' + config.game.entity + '.js');
        entity = new entity(broadcast);
        if(!entity) {
            console.log('entity requested doesn\'t exist in entity folder.Server Stopped.');
            return false;
        }

        /**
         * setup Server Socket
         */
        var sockServer = sockjs.createServer(config.server);

        /**
         * Setup team game mode
         */
        if(config.game.use_team) {
            var team = require('./team.js');
            team.setConfig(config.game);
        }

        /**
         * Socket on connection function
         *
         * @func connection
         * @param conn
         */
        sockServer.on('connection', function(conn) {

            client_id++;
            client_ids[client_id];
            if(config.debug) {
                console.log('	[+] echo open    ' + conn);
            }

            /************** TEAM **************/
            if(config.game.use_team) {
                if(team.getLength() == config.game.team.nb) {
                    if(config.debug) {
                        console.log('No teams available');
                    }
                    broadcast.update(conn, {error: {level: 'info', message: 'No teams available'}});
                    return false;
                }
                var teamToSync = team.addToTeam(conn);
                broadcast.update(null, {n:'team.sync',d:{data: teamToSync}});
            }
            /************* END TEAM ***********/

            /************* SOCKETS ************/
            broadcast.setSockClients(conn);
            entity.init(
                conn,
                broadcast.getSockClients()
            );
            /************ END SOCKETS *********/

            /************ ENTITY **************/
            //Create and add new Entity
            var entityCreated = entity.create(conn, broadcast.getSockClients());
            broadcast.addUser(conn, entityCreated);

            if(config.debug) {
                console.log('socket client result ' + broadcast.getSockClients([conn.id]));
            }

            entity.action(conn, 'entity.update', null);
            /************ END ENTITY **********/

            /**
             * Event data sent
             */
            conn.on('data', function(m) {
                var json = JSON.parse(m);
                if(json.f == 'message') {
                    console.log(json.d);
                } else {
                    entity.action(conn, json.f, json.d);
                }
            });

            /**
             * Event connection close
             */
            conn.on('close', function() {
                conn.close();
                broadcast.removeSocketClient(conn.id);
                if(config.game.use_team) {
                    team.deleteFromTeam(conn.id, conn.team);
                }
                entity.deleteEntity(conn.id);
                if(config.debug) {
                    console.log('"close" request => ' + conn);
                }
            });
        });

        sockServer.on('message', function(conn, m) {
            if(config.debug) {
                console.log('"message" request => ' + JSON.stringify(m));
            }
            conn.write(m);
        });

        /**
         * Start up Server
         */
        /* Setup request listener */
        var httpServer = http.createServer(function (req, res) {});

        /* Socket Server listener on different action */
        sockServer.installHandlers(httpServer, {prefix:'/echo', response_limit: 4096}),
        sockServer.installHandlers(httpServer, {prefix:'/socket', info: true}),
        sockServer.installHandlers(httpServer, {prefix:'/message', info: true}),
        sockServer.installHandlers(httpServer, {prefix:'/close'});
        /* Start listen... */
        httpServer.listen(config.server.port, config.server.host);

    } catch (ex) {
        console.log('EXCEPTION => ' + ex);
    }
};
