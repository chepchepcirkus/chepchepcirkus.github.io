/**
 * @TODO nb + time of party
 *
 * @type {{debug: boolean, server: {port: number, host: string, sockjs_url: string, websocket: boolean}, game: {entity: string, use_team: boolean, team: {nb: number, nb_team_min: number, nb_team_max: number}}}}
 */
exports.config = {
    debug:true,
    server: {
        port: 3000,
        host: 'localhost',
        websocket: true,
    },
    game: {
        entity: 'loonyball',
        use_team: false,
        team: {
            nb:4,
            nb_team_min:1,
            nb_team_max:2
        }
    }
};
