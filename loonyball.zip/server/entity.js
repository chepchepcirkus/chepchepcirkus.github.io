'use strict';
var index = 0;
var Entity = function (broadcast) {
    this.broadcast = broadcast;
    this.client_entities = {};
    this.index;
}
/**
 * Initialize user in game
 *
 * @important interface method
 *
 */
Entity.prototype.init = function (connexion, sock_clients) {
    this.index =  index++;
    this.broadcast.update(
        {f:'entity.init', d:{id:this.index}},
        this.broadcast.getSockClients(connexion.id)
    );
};

/**
 * Dummy entity
 *
 * @returns {{id: string, remoteOpts: {}}}
 */
Entity.prototype.entity = function (connexionId){
    return {
        id: connexionId,
        remoteOpts: {}
    }
};

/**
 * Create entity
 *
 * @important interface method
 * @param connexion
 */
Entity.prototype.create = function (connexion) {};

/**
 * Action dealer
 *
 * @important interface method
 */
Entity.prototype.action = function (connexionId, action, data) {};

/**
 * Remove entity
 *
 * @important interface method
 */
Entity.prototype.deleteEntity = function (connexionId) {
    for(var i in this.client_entities){
        if(this.client_entities[i].id == connexionId) {
            delete this.client_entities[i];
        }
    }
    this.broadcast.update({f:'entity.delete', d:[connexionId]});
    this.action(connexionId, 'update', '');
};

/**
 * Get only data from client object to send
 *
 * @param client
 * @returns {Array}
 */
Entity.prototype.getRemoteOpts = function (client) {
    if(client == null) {
        client = this.client_entities;
    }
    var data = {};
    for(var i in client){
        if(client[i].remoteOpts != null) {
            data[client[i].remoteOpts.id] = client[i].remoteOpts;
        }
    }
    return data;
};

/**
 * Set only data from client object to send
 *
 * @param client
 * @returns {Array}
 */
Entity.prototype.setRemoteOpts = function (data) {
    console.log(data);
    for(var i in data){
        this.client_entities[i].remoteOpts = data[i];
    }
};
/**
 * Custom update
 *
 * @param connexionId
 * @param client_entities
 */
Entity.prototype.customUpdate = function (connexionId, client_entities) {
    var i;
    for(i in this.client_entities) {
        this.broadcast.update({f:'entity.new', d:this.getRemoteOpts()}, this.broadcast.getSockClients(connexionId));
    }
    this.broadcast.updateOther({f:'entity.new', d:this.getRemoteOpts()}, connexionId);
};
module.exports = Entity;


