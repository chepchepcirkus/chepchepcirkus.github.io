/**
 * Broadcast Object
 *
 * @param connexion
 * @param sock_clients
 */
function Broadcast (){
    var sock_clients = [];

    /**
     * Add Socket Client
     *
     * @param connexion
     * @returns {exports}
     */
    function setSockClients(connexion) {
        sock_clients.push(connexion);
        return this;
    }

    /**
     * Retrieve client socket from an connexion id or get all active client sockets
     *
     * @param connexionId
     * @returns {*}
     */
    function getSockClients(connexionId) {
        if(connexionId != null) {
            var i;
            if(typeof connexionId == Array) {
                //return sockets corresponding to array param
                Array.prototype.contains = function (v) {
                    return this.indexOf(v) > -1;
                };
                var values = [];
                for(i in sock_clients) {
                    if(sock_clients[i].id == connexionId.contains(sock_clients[i].id)) {
                        values.push(sock_clients[i]);
                    }
                }
                return values;
            }
            else{
                //return single socket in param
                for(i in sock_clients) {
                    if(sock_clients[i].id == connexionId) {
                        return sock_clients[i];
                    }
                }
            }
            return new Array();
        }
        else{
            return sock_clients;
        }
    }

    /**
     * Remove client socket
     *
     * @param connexionId
     * @returns {boolean}
     */
    function removeSocketClient (connexionId) {
        if(connexionId != null) {
            var i;
            for(i in sock_clients) {
                if(sock_clients[i].id == connexionId) {
                    delete sock_clients[i];
                    this.update({f:'user.delete', d:{id: connexionId}});
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Update All client sockets
     *
     * @param clientsToBroadcast
     * @param message
     */
    function update(message, clientsToBroadcast) {
        if(clientsToBroadcast == null) {
            clientsToBroadcast = this.getSockClients();
        }
        if(!Array.isArray(clientsToBroadcast )) {
            clientsToBroadcast = new Array(clientsToBroadcast);
        }
        for(var client in clientsToBroadcast){
            clientsToBroadcast[client].write(JSON.stringify(message));
        }
    }

    /**
     * Update client sockets but not active socket
     *
     * @param connexionId
     * @param clientsToBroadcast
     * @param message
     */
    function updateOther(message, connexionId, clientsToBroadcast) {
        if(clientsToBroadcast == null) {
            clientsToBroadcast = this.getSockClients();
        }
        for(var client in clientsToBroadcast){
            if(connexionId != clientsToBroadcast[client].id) {
                clientsToBroadcast[client].write(JSON.stringify(message));
            }
        }
    }

    /**
     * Add user
     *
     * @param connexion
     * @param client_entity
     */
    function addUser(connexion, client_entity) {
        this.update({f:'user.add', d:{id: connexion.id, name:client_entity.name}});
        this.syncUser(connexion, client_entity);
    }

    /**
     * Synchronize User
     *
     * @param connexion
     * @param client_entity
     */
    function syncUser(connexion, client_entity) {
        this.update({f:'user.sync', d:{id: connexion.id, name:client_entity.name}});
    }

    return {
        syncUser : syncUser,
        addUser : addUser,
        updateOther : updateOther,
        setSockClients : setSockClients,
        getSockClients : getSockClients,
        removeSocketClient : removeSocketClient,
        update : update,
    }
}
module.exports = Broadcast;