(function () {
    'use strict';
    this.counter = 0;
    this.teams = {};
    this.uncompletedTeam = [];
    this.config = {};

    /**
     * Create new team
     * init connexion id in uncompletedTeam Array
     *
     * @param connexionId
     * @returns {Array} team created
     */
    exports.setConfig = function (config) {
        this.config = config;
    };

    /**
     * Create new team
     * init connexion id in uncompletedTeam Array
     *
     * @param connexionId
     * @returns {Array} team created
     */
    exports.newteam = function () {
        this.counter++;
        var code = 'team_' + this.counter;
        this.uncompletedTeam.push(code);
        this.teams[code] = {};
        this.teams[code].name = 'Team ' + this.counter;
        return code;
    };

    /**
     * Delete connexion id from a team
     * and check team availability
     *
     * @param connnexionId
     * @param code
     */
    exports.deleteFromTeam = function (connnexionId, code) {
        if(this.teams[code] != "undefined") {
            for(var i in this.teams[code].members) {
                if(this.teams[code].members[i] == connnexionId) {
                    this.teams[code].members.splice(i);
                }
            }
            if(this.config.team.nb_team_min > this.teams[code].members.length <= this.config.team.nb_team_max) {
                this.uncompletedTeam.push(code);
            }
        }
    };

    /**
     * Add connexion Id to team Array
     * @param team
     * @param connexionId
     */
    exports.addUserToTeam = function(code, team, connexionId) {
        this.teams[code].members.push(connexionId);
        return this.teams[code];
    };

    /**
     * Add connexion Id to a team
     * Fill uncompleted team
     * or create new team
     *
     * @param connexionId
     * @returns {Array}
     */
    exports.addToTeam = function (connexion){
        if(this.uncompletedTeam.length == 0) {
            var code = this.newteam();
            connexion.team = code;
            this.teams[code].members = [connexion.id];
            return this.teams[code];
        }
        else {
            var code = this.uncompletedTeam.shift();
            var data = this.addUserToTeam(code, this.teams[code], connexion.id);
            connexion.team = code;
            if(this.config.team.nb_team_min > this.teams[code].members.length <= this.config.team.nb_team_max) {
                this.uncompletedTeam.push(code);
            }
            return data;
        }
    };
    exports.getLength = function () {
        return this.teams.length;
    };
}).call(this);